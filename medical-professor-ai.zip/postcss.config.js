export default {
  plugins: {
    // Plugins are now handled by Vite or not required.
  },
}