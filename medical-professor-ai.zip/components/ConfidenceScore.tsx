import React from 'react';

// This component is currently used inline or deprecated, keeping file to prevent build breaks.
export const ConfidenceScore: React.FC = () => {
  return null;
};